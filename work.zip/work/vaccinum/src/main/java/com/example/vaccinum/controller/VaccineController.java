package com.example.vaccinum.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 疫苗 前端控制器
 * </p>
 *
 * @author jerry
 * @since 2023-10-21
 */
@RestController
@RequestMapping("/vaccinum/vaccine")
public class VaccineController {

}
